package com.example.asistentepersonal

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private val prefs by lazy { getSharedPreferences("nova", MODE_PRIVATE) }
    private var addMessage: ((String, Boolean) -> Unit)? = null
    private var setBusy: ((Boolean) -> Unit)? = null

    private val voiceLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { commandHandler(it) }
    }

    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        tts = TextToSpeech(this, this)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        setContent { NovaApp() }
    }

    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts.language = Locale("es", "ES") }
    private fun speak(text: String) { if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nova") }

    private fun listen() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-CO")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Habla con NOVA")
        }
        voiceLauncher.launch(i)
    }

    private fun commandHandler(raw: String) {
        val text = raw.trim()
        if (text.isBlank()) return
        addMessage?.invoke(text, true)
        val lower = text.lowercase(Locale.getDefault())
        when {
            lower.contains("hora") -> reply("Son las ${SimpleDateFormat("h:mm a", Locale("es","CO")).format(Date())}")
            lower.contains("fecha") || lower.contains("qué día") || lower.contains("que dia") -> reply("Hoy es ${SimpleDateFormat("EEEE d 'de' MMMM 'de' yyyy", Locale("es","CO")).format(Date())}")
            lower == "hola" || lower.startsWith("hola ") -> reply("¡Hola! Soy NOVA. Puedo ayudarte con notas, recordatorios, búsquedas, WhatsApp, aplicaciones y preguntas con IA.")
            lower.startsWith("abre ") || lower.startsWith("abrir ") -> openApp(lower.removePrefix("abre ").removePrefix("abrir ").trim())
            lower.contains("youtube") -> openUrl("https://www.youtube.com", "Abriendo YouTube.")
            lower.contains("google") -> openUrl("https://www.google.com", "Abriendo Google.")
            lower.startsWith("busca ") || lower.startsWith("buscar ") -> {
                val q = lower.removePrefix("busca ").removePrefix("buscar ").trim(); openUrl("https://www.google.com/search?q=" + Uri.encode(q), "Buscando $q.")
            }
            lower.startsWith("whatsapp ") || lower.contains("abre whatsapp") -> openWhatsApp()
            lower.startsWith("nota ") || lower.startsWith("anota ") -> saveNote(text.substringAfter(' ').trim())
            lower.startsWith("recordatorio ") -> scheduleReminder(text.substringAfter(' ').trim())
            lower == "mis notas" || lower == "mostrar notas" -> showNotes()
            lower == "ayuda" || lower == "qué puedes hacer" || lower == "que puedes hacer" -> reply("Puedes decir: abre YouTube, busca noticias, abre WhatsApp, nota comprar pan, recordatorio 10 minutos estudiar, mis notas, hora, fecha o preguntarme cualquier cosa si configuras la IA.")
            else -> askAI(text)
        }
    }

    private fun reply(text: String, speakIt: Boolean = true) { addMessage?.invoke(text, false); if (speakIt) speak(text) }

    private fun saveNote(note: String) {
        if (note.isBlank()) return reply("Dime qué quieres guardar en la nota.")
        val notes = prefs.getStringSet("notes", emptySet())!!.toMutableSet(); notes.add("${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())}: $note")
        prefs.edit().putStringSet("notes", notes).apply(); reply("Listo. Guardé la nota.")
    }
    private fun showNotes() {
        val notes = prefs.getStringSet("notes", emptySet())!!.toList().sortedDescending()
        reply(if (notes.isEmpty()) "No tienes notas guardadas." else "Tus notas:\n" + notes.joinToString("\n"), false)
    }

    private fun scheduleReminder(command: String) {
        val regex = Regex("(?i)(?:en\\s+)?(\\d+)\\s*(minutos?|mins?|horas?|h)\\s*(?:para|:)?\\s*(.*)")
        val m = regex.find(command)
        if (m == null) return reply("Ejemplo: recordatorio 10 minutos estudiar programación")
        val amount = m.groupValues[1].toLong(); val unit = m.groupValues[2].lowercase(); val message = m.groupValues[3].ifBlank { "Recordatorio de NOVA" }
        val millis = if (unit.startsWith("h")) amount * 3600000L else amount * 60000L
        val intent = Intent(this, ReminderReceiver::class.java).putExtra("message", message)
        val pi = PendingIntent.getBroadcast(this, System.currentTimeMillis().toInt(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (getSystemService(ALARM_SERVICE) as AlarmManager).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + millis, pi)
        reply("Listo. Te recordaré: $message en $amount ${m.groupValues[2]}.")
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("nova_reminders", "Recordatorios NOVA", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun openUrl(url: String, message: String) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))); reply(message) }
    private fun openWhatsApp() {
        val i = packageManager.getLaunchIntentForPackage("com.whatsapp")
        if (i != null) { startActivity(i); reply("Abriendo WhatsApp.") } else reply("No encontré WhatsApp instalado.")
    }
    private fun openApp(name: String) {
        val map = mapOf("youtube" to "com.google.android.youtube", "whatsapp" to "com.whatsapp", "chrome" to "com.android.chrome", "facebook" to "com.facebook.katana", "instagram" to "com.instagram.android", "spotify" to "com.spotify.music")
        val pkg = map[name] ?: run { reply("Todavía no tengo configurada la aplicación $name. Puedes pedirme abrir YouTube, WhatsApp, Chrome, Facebook, Instagram o Spotify."); return }
        val i = packageManager.getLaunchIntentForPackage(pkg); if (i != null) { startActivity(i); reply("Abriendo $name.") } else reply("No encontré $name instalado.")
    }

    private fun askAI(text: String) {
        val key = prefs.getString("api_key", "") ?: ""
        if (key.isBlank()) return reply("Puedo responder con IA, pero primero entra en Configuración y agrega tu clave de API. También puedo ayudarte sin IA con comandos como hora, notas, recordatorios, búsquedas y aplicaciones.")
        setBusy?.invoke(true)
        Thread {
            val result = runCatching { callOpenAI(key, text) }.getOrElse { "No pude conectar con la IA: ${it.message ?: "error desconocido"}" }
            runOnUiThread { setBusy?.invoke(false); reply(result) }
        }.start()
    }

    private fun callOpenAI(key: String, text: String): String {
        val conn = (URL("https://api.openai.com/v1/responses").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 15000; readTimeout = 30000; doOutput = true
            setRequestProperty("Authorization", "Bearer $key"); setRequestProperty("Content-Type", "application/json")
        }
        val body = JSONObject().apply {
            put("model", prefs.getString("model", "gpt-5.6-luna"))
            put("input", JSONArray().put(JSONObject().apply { put("role", "user"); put("content", JSONArray().put(JSONObject().apply { put("type", "input_text"); put("text", "Eres NOVA, un asistente personal en español. Sé útil y breve. Usuario: $text") })) }))
        }
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        if (conn.responseCode !in 200..299) throw IllegalStateException("HTTP ${conn.responseCode}: ${response.take(300)}")
        val json = JSONObject(response)
        val output = json.optJSONArray("output") ?: return response
        for (i in 0 until output.length()) {
            val item = output.optJSONObject(i) ?: continue
            val content = item.optJSONArray("content") ?: continue
            for (j in 0 until content.length()) {
                val c = content.optJSONObject(j) ?: continue
                val t = c.optString("text")
                if (t.isNotBlank()) return t
            }
        }
        return "La IA no devolvió texto."
    }

    @Composable fun NovaApp() {
        var input by remember { mutableStateOf("") }
        var busy by remember { mutableStateOf(false) }
        var showSettings by remember { mutableStateOf(false) }
        val messages = remember { mutableStateListOf<Pair<String, Boolean>>() }
        addMessage = { text, user -> messages.add(text to user) }
        setBusy = { busy = it }
        if (showSettings) SettingsScreen(onBack = { showSettings = false }) else MaterialTheme {
            Scaffold(topBar = { TopAppBar(title = { Text("NOVA") }, actions = { TextButton(onClick = { showSettings = true }) { Text("Configuración") } }) }) { pad ->
                Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)) {
                    Text("Tu asistente personal", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                        items(messages) { (msg, user) -> Row(Modifier.fillMaxWidth().padding(vertical=4.dp), horizontalArrangement = if(user) Arrangement.End else Arrangement.Start) { Surface(tonalElevation=2.dp, shape=MaterialTheme.shapes.medium) { Text(msg, Modifier.padding(12.dp)) } } }
                    }
                    if (busy) Text("NOVA está pensando…", Modifier.padding(4.dp))
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        OutlinedTextField(value=input, onValueChange={input=it}, modifier=Modifier.weight(1f), placeholder={Text("Escribe algo…")})
                        Spacer(Modifier.width(6.dp)); Button(onClick={ if(input.isNotBlank()){ commandHandler(input); input="" } }) { Text("Enviar") }
                    }
                    Spacer(Modifier.height(8.dp)); Button(onClick={listen}, Modifier.fillMaxWidth()) { Text("🎙 Hablar con NOVA") }
                }
            }
        }
    }

    @Composable fun SettingsScreen(onBack: () -> Unit) {
        var key by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
        var model by remember { mutableStateOf(prefs.getString("model", "gpt-5.6-luna") ?: "gpt-5.6-luna") }
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Text("Configuración de NOVA", style=MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(12.dp)); Text("IA opcional", style=MaterialTheme.typography.titleMedium)
            Text("Para usar IA, introduce tu clave de API. La clave se guarda localmente en este teléfono. Para una app publicada, lo recomendable es usar un servidor intermedio y no exponer claves en el APK.", style=MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(12.dp)); OutlinedTextField(key, {key=it}, Modifier.fillMaxWidth(), label={Text("Clave API")}, visualTransformation=PasswordVisualTransformation())
            Spacer(Modifier.height(8.dp)); OutlinedTextField(model, {model=it}, Modifier.fillMaxWidth(), label={Text("Modelo")})
            Spacer(Modifier.height(12.dp)); Button(onClick={ prefs.edit().putString("api_key",key.trim()).putString("model",model.trim()).apply(); onBack() }, Modifier.fillMaxWidth()) { Text("Guardar") }
            Spacer(Modifier.height(8.dp)); OutlinedButton(onClick=onBack, Modifier.fillMaxWidth()) { Text("Volver") }
        }
    }

    override fun onDestroy() { if (::tts.isInitialized) { tts.stop(); tts.shutdown() }; super.onDestroy() }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val message = intent.getStringExtra("message") ?: "Tienes un recordatorio de NOVA."
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel("nova_reminders", "Recordatorios NOVA", NotificationManager.IMPORTANCE_HIGH))
        val notification = Notification.Builder(context, "nova_reminders").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("NOVA — Recordatorio").setContentText(message).setAutoCancel(true).build()
        manager.notify(System.currentTimeMillis().toInt(), notification)
    }
}
